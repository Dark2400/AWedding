# Driver class for Evolutionary Population Epop
# COEN 432
# Marc Bass - 26488994
# 01/27/2018
#
#


import EPop

obj1 = EPop.EPop(pop = 1000, 
                 children = 2, 
                 generations = 10, 
                 tourn = 5, 
                 prob = 0.15, 
                 fitnessTarget = 10,
                 growth = 7,
                 windowSize = 15,
                 settings = "settings.txt", 
                 guestsPref = "preferences.csv",
                 output = "output.csv")

obj1.testSuite()
del obj1

lambdaPlus = True
useDiversity = False
obj2 = EPop.EPop(pop = 100, 
                 children = 2, 
                 generations = 20, 
                 tourn = 5, 
                 prob = 0.3, 
                 fitnessTarget = 10,
                 growth = 7,
                 windowSize = 10,
                 settings = "settings.txt", 
                 guestsPref = "preferences.csv",
                 output = "output.csv")

obj2.generations( useDiversity = useDiversity, lambdaPlus = lambdaPlus)
del obj2
lambdaPlus = False
obj3 = EPop.EPop(pop = 100, 
                 children = 2, 
                 generations = 10, 
                 tourn = 5, 
                 prob = 0.3, 
                 fitnessTarget = 10,
                 growth = 7,
                 windowSize = 10,
                 settings = "settings.txt", 
                 guestsPref = "preferences2.csv",
                 output = "output.csv")
# Compares /w and w/o Crowding
obj3.testDiversity(lambdaPlus)
del obj3
     